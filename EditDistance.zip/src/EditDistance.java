import java.util.*;

public class EditDistance implements EditDistanceInterface {

	int c_i, c_d, c_r;
	int MAX = Integer.MAX_VALUE;
	int UNDEF = -1;

	public EditDistance(int c_i, int c_d, int c_r){
		this.c_i = c_i;
		this.c_d = c_d;
		this.c_r = c_r;
	}

	public int[][] editDistance(String s1, String s2) {
		int n1=s1.length();
		int n2=s2.length();
		int[][] d=new int[n1+1][n2+1];// On initialise le tableau r�sultat avec des -1
		for (int k=0;k<n1+1;k++) {
			for (int l=0;l<n2+1;l++) {
				d[k][l]=-1;
			}
		}
		d[0][0]=0;
		//for (int i=0;i<n1;i++) {  Premi�re question
		//	d[i][0]=i*c_d;
		//}
		//for (int j=0;j<n2;j++) {
		//	d[0][j]=j*c_i;
		//}
		//for (int i=1;i<n1+1;i++) {
		//	for (int j=1;j<n2+1;j++) {
		//		if (s1.charAt(i-1)==s2.charAt(j-1)) {
		//			d[i][j]=d[i-1][j-1];
		//		}
		//		else {
		//			d[i][j]=Math.min(Math.min(d[i-1][j-1]+c_r,d[i-1][j]+c_d),d[i][j-1]+c_i);
		//	}
		//	}
		//}
		/* To be optimized in Q2 */

		editDistanceAux(s1,n1,s2,n2,d);// Deuxi�me question
		return d;
	}


	public void editDistanceAux(String s1, int i, String s2, int j, int[][]m) {
		if (i==0 || j==0) {
			m[i][j]=c_i*j+c_d*i;
		}
		else {
			if (m[i-1][j-1]==-1) {//On v�rifie qu'on a pas d�j� stock� la valeur recherch�e
				editDistanceAux(s1,i-1,s2,j-1,m);// Sinon on la calcule
			}
			if (s1.charAt(i-1)==s2.charAt(j-1)) {//Si les lettres courantes sont identiques
				m[i][j]=m[i-1][j-1];             //on ne fait rien
			}
			else {
				int MIN=m[i-1][j-1]+c_r;//Initialisation du MIN
				if (MIN>c_d) {
					if (m[i-1][j]==-1) {//On v�rifie qu'on a pas d�j� stock� la valeur 
						editDistanceAux(s1,i-1,s2,j,m);}//Sinon on calcule
					MIN=Math.min(m[i-1][j]+c_d,MIN);//On prend le MIN des deux
				}
				if (MIN>c_i) {//M�me chose pour l'insertion
					if (m[i][j-1]==-1) {
						editDistanceAux(s1,i,s2,j-1,m);
					}
					MIN=Math.min(m[i][j-1]+c_i,MIN);
				}
				m[i][j]=MIN;
			}
		}
	}

	public void editDistanceAux2(String s1, int i, String s2, int j, int[][]m,String[][] op) {
		if (i==0 || j==0) {     //L'algorithme est quasiment identique, sauf qu'on impl�mente
			m[i][j]=c_i*j+c_d*i;//un tableau op dans lequel on stocke les op�rations effectu�s
			if (j==0) {
				if (i!=0) {
					op[i][j]="delete("+0+")";
				}
			}
			if (i==0) {
				if (j!=0) {
					int j2=j-1;
					op[i][j]="insert("+j2+","+s2.charAt(j-1)+")";
				}
			}
		}
		else {
			if (m[i-1][j-1]==-1) {
				editDistanceAux2(s1,i-1,s2,j-1,m,op);}
			if (s1.charAt(i-1)==s2.charAt(j-1)) {
				m[i][j]=m[i-1][j-1];
				op[i][j]=op[i-1][j-1];
			}
			else {
				int MIN=m[i-1][j-1]+c_r;
				int i2=i-1;
				String min="replace("+i2+","+s2.charAt(j-1)+")";
				if (MIN>c_d) {
					if (m[i-1][j]==-1) {
						editDistanceAux2(s1,i-1,s2,j,m,op);}
					if (MIN>m[i-1][j]+c_d) {
						MIN=m[i-1][j]+c_d;
						min="delete("+i2+")";
					}
				}
				if (MIN>c_i) {
					if (m[i][j-1]==-1) {
						editDistanceAux2(s1,i,s2,j-1,m,op);}
					if (MIN>m[i][j-1]+c_i) {
						MIN=m[i][j-1]+c_i;
						min="insert("+i+","+s2.charAt(j-1)+")";
					}
				}
				m[i][j]=MIN;
				op[i][j]=min;
			}
		}
	}
	public List<String> minimalEdits(String s1, String s2) {
		int n1=s1.length();
		int n2=s2.length();
		int[][] d=new int[n1+1][n2+1];
		for (int k=0;k<n1+1;k++) {
			for (int l=0;l<n2+1;l++) {
				d[k][l]=-1;
			}
		}
		d[0][0]=0;
		List<String> L=new LinkedList<String>();
		int k=n1;
		int l=n2;
		String[][] op=new String[n1+1][n2+1];
		for (int r=0;r<n1+1;r++) {
			for (int t=0;t<n2+1;t++) {
				op[r][t]="nothing";
			}
		}
		editDistanceAux2(s1,n1,s2,n2,d,op);
		while (k!=0 && l!=0) {
			if (op[k][l]==op[k-1][l-1] || op[k-1][l-1]==null) {//Si on a deux lettres identiques
				k--;                                           //On prend la diagonale
				l--;
			}
			else {//On effectue le chemin inverse pour �grener les op�rations
				L.add(op[k][l]);
				if (op[k][l].charAt(0)=='d') {//Si on supprime on va en haut
					k--;
				}
				else if(op[k][l].charAt(0)=='i') {//Si on insert on va � gauche 
					l--;
				}
				else if(op[k][l].charAt(0)=='r') {//Si on substitue on prend la diagonale
					k--;
					l--;      
				}
			}
		}
		if (k==0) {//Cas limite k=0 ou l=0. 
			while (l!=0) {
				L.add(op[k][l]);
				l--;
			}
		}
		if (l==0) {
			while (k!=0) {
				L.add(op[k][l]);
				k--;
			}
		}
		return L;
	}
}
